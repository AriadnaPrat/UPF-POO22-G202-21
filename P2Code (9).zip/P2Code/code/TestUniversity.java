public class TestUniversity {
    public static void main( String[] args ) {
        //Crea una instancia de University
		University university=new University();
        //Imprime los Students, Courses, teachers y Classrooms de University.
        System.out.println(university.getStudents());
        System.out.println(university.getCourses());
        System.out.println(university.getClassrooms());
        System.out.println(university.getTeachers());
        //Imprime los courses del Student indicado.
        System.out.println(university.coursesOfStudent("Ron Weasley")) ;
        //Imprimer los teachers del course indicado.
        System.out.println(university.teachersOfCourse("Transformations")) ;
	  }
}
