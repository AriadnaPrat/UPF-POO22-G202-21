import java.util.LinkedList;
public class Teacher{
    private String name;
    private LinkedList<Assignment>assignments=new LinkedList<Assignment>();
    //El constructor de Teacher
    public Teacher(String name){
        this.name=name;
    }
    //Añade un assignment a la lista.
    public void addAssignment(Assignment assignment){
        this.assignments.add(assignment);
    }
    //Coge el name de teacher.
    public String toString(){
        return this.name;
    }
    
}