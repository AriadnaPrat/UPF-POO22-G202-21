import java.util.LinkedList;
public class Classroom {
    private String code;
    private LinkedList<Lecture>lectures=new LinkedList<Lecture>();
    //El constructor de Classroom
    public Classroom(String code){
        this.code=code;
    }
    //Añade un Lecture a la lista
    public void addLecture(Lecture lecture){
        this.lectures.add(lecture);
    }
    
    public String toString(){
        return this.code;
    }
}