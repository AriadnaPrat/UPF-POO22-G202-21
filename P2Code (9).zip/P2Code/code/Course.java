import java.util.LinkedList;
public class Course{
    private String name;
    private LinkedList<Enrollment>enrollments=new LinkedList<Enrollment>();
    private LinkedList<Assignment>assignments=new LinkedList<Assignment>();
    private LinkedList<Lecture>lectures=new LinkedList<Lecture>();
    //Es el constructor Course.
    public Course(String name){
        this.name=name;
    }
    //Añade un Lecture a la lista de lectures de la clase.
    public void addLecture(Lecture lecture){
        this.lectures.add(lecture);
    }
    //Añade un assignment a la lista de assignments de la clase.
    public void addAssignment(Assignment assignment){
        this.assignments.add(assignment);
    }
    //Añade un Enrolllment a la lista.
    public void addEnrollment(Enrollment enrollment){
        this.enrollments.add(enrollment);
    }
    //Devuelve name.
    public  String toString(){
        return this.name;
    }
    //Devuelve la lista de teachers del course indicado.
    public LinkedList<String> getTeachers(LinkedList<Teacher> teachers){
        LinkedList<String> teachers1= new LinkedList<String>();
        for (Assignment array: this.assignments){
            for(Teacher array1: teachers){
                if(array.getTeacher()==array1){
                    teachers1.add(array.getTeacher().toString());
                }
            }
        }
        return teachers1;
    }
}