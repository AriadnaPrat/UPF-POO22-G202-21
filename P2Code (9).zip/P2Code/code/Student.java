import java.util.LinkedList;
public class Student{
    private String name;
    private int nia;
    private LinkedList<Enrollment> enrollments=new LinkedList<Enrollment>();
    //El constructor de student.
    public Student(String name, int num){
        this.name=name;
        this.nia=num;
    }
    //Añadir Enrollment a la lista de enrollments de student
    public void addEnrollment(Enrollment enrollment){
        this.enrollments.add(enrollment);
    }
    //Coge los courses de la lista enrollments del student y los devuelve.
    public LinkedList<String> getCourses(LinkedList<Course> courses){
        LinkedList<String> courses1= new LinkedList<String>();
        for (Enrollment array: this.enrollments){
            for(Course array1: courses){
                if(array.getCourse()==array1){
                    courses1.add(array.getCourse().toString());
                }
            }
        }
        return courses1;
    }
    //Devuelve el name del student
    public String toString(){
        return this.name;
    }
}