import java.util.LinkedList;
public class University {
    private LinkedList<Course>courses= new LinkedList<Course>();
    private LinkedList<Classroom>classrooms= new LinkedList<Classroom>();
    private LinkedList<Student>students= new LinkedList<Student>();
    private LinkedList<Teacher>teachers= new LinkedList<Teacher>();

    public University(){
        //Se inicializan y se coge la información dw los archivos XML
        LinkedList<Student> studentList = new LinkedList<Student>();
        LinkedList<Teacher> teacherList = new LinkedList<Teacher>();
        LinkedList<Classroom> classroomList = new LinkedList<Classroom>();
        LinkedList<Course> courseList = new LinkedList<Course>();
        LinkedList<String[]> classrooms= Utility.readXML("classroom");
        LinkedList<String[]> lectures = Utility.readXML("lecture");
        LinkedList<String[]> students = Utility.readXML("student"); 
        LinkedList<String[]> teachers = Utility.readXML("teacher");
        LinkedList<String[]> courses = Utility.readXML("course");
        LinkedList<String[]> assignments = Utility.readXML("assignment");
        LinkedList<String[]> enrollments = Utility.readXML("enrollment");
        //Se almacena la información de los archivos XML a su respectiva classe con un for
        for(String[] array: students){
            Student student=new Student(array[0],Integer.parseInt(array[1]));// array[0] es el name y array[1] es el NIA.
            studentList.add(student);// una vez lo tenemos parseado, lo agregamos
        }
        for(String[] array: teachers){
            Teacher teacher=new Teacher(array[0]);
            teacherList.add(teacher);
        }

        for(String[] array: courses){
            Course course=new Course(array[0]);
            courseList.add(course);
        }

        for(String[] array: classrooms){
            Classroom classroom=new Classroom(array[0]);
            classroomList.add(classroom);
        }
        //Se analiza los lectures para almacenar cada lecture sus datos y cada lecture a su respectiva classroom y course. 
        for (String[] array: lectures) {
            Classroom classroom = Utility.getObject(array[0], classroomList); // está buscando dentro de todos los classroom, el valor de array[0].
            Course course = Utility.getObject(array[1], courseList);
            Lecture lecture = new Lecture(array[4],Integer.parseInt(array[2]),Integer.parseInt(array[3])); // estámos guardando [0] classroomCode, [1] courseName, [2] slot, [3] type, [4] group
            lecture.addClassroom(classroom); 
            lecture.addCourse(course);
            classroom.addLecture(lecture); // guardamos el objeto de tipo lecture
            course.addLecture(lecture); 
        }
        //Se analiza los enrollments para almacenar cada enrollment sus datos y cada enrollment a su respectiva student y course.
        for (String[] array: enrollments){
            Student student=Utility.getObject(array[0], studentList); //array[0] es el name del student correspondiente
            Course course = Utility.getObject(array[1], courseList); //array[1] es el name del course.
            Enrollment enrollment = new Enrollment(array[2]); //crea un enrollment con el seminargroup
            enrollment.addStudent(student); //Se añade student al enrollment
            enrollment.addCourse(course); //Se añade course al enrollment
            course.addEnrollment(enrollment); //Se añade enrollment al course.
            student.addEnrollment(enrollment); //Se añade enrollment al student.
        }
        //Se analiza los assignments para almacenar cada assignment sus datos y cada assignment a su respectiva teacher y course.
        for (String[] array: assignments){
            Teacher teacher=Utility.getObject(array[0],teacherList); //array[0] es el nombre del teacher y devuelve el teacher correspondiente
            Course course = Utility.getObject(array[1], courseList); //array[1] es el nombre del course 
            LinkedList<String>groupList=new LinkedList<String>(); 
            for(int i=2;i<array.length;i++){//Va almacenando los groups para crear el assignment
                groupList.add(array[i]);
            }
            Assignment assignment=new Assignment(groupList);
            assignment.addTeacher(teacher); //Se añade teacher al assignment
            assignment.addCourse(course); //Se añade course al assignment
            teacher.addAssignment(assignment); //Se añade assignment al teacher
            course.addAssignment(assignment); //Se añade assignment al course
        }
        //Almacena las listas en los atributos correspondientes.
        for(Course array: courseList){
            this.courses.add(array);
        }
        for(Student array: studentList){
            this.students.add(array);
        }
        for(Classroom array: classroomList){
            this.classrooms.add(array);
        }
        for(Teacher array: teacherList){
            this.teachers.add(array);
        }
    }
    // los getters devolverán la información de las listas
    public LinkedList<String> getStudents(){
        return Utility.toString(this.students);
    }
    public LinkedList<String> getCourses(){
        return Utility.toString(this.courses);
    }
    public LinkedList<String> getClassrooms(){
        return Utility.toString(this.classrooms);
    }
    public LinkedList<String> getTeachers(){
        return Utility.toString(this.teachers);
    }
    //Esta querie identifica el student y con getcourses devuelve los courses que tiene dicho student.
    public LinkedList<String> coursesOfStudent(String student){
        return Utility.getObject(student,this.students).getCourses(this.courses);
    }
    //Esta querie identifica el course y con getTeachers devuelve los teachers que tiene dicho course.
    public LinkedList<String> teachersOfCourse(String course){
        return Utility.getObject(course,this.courses).getTeachers(this.teachers);
    }

}
