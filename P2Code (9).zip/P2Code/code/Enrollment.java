public class Enrollment {
    private String seminarGroup;
    private Student student;
    private Course course;
    //Es el constructor Enrollment-
    public Enrollment(String seminarGroup){
        this.seminarGroup=seminarGroup;
    }
    //Añade el course a la clase
    public void addCourse(Course course){
        this.course=course;
    }
    //Añade el student a la clase.
    public void addStudent(Student student){
        this.student=student;
    }
    //Devuelve el course de la clase.
    public Course getCourse(){
        return course;
    }
}
