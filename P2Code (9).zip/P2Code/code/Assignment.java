import java.util.LinkedList;
public class Assignment{
    private Teacher teacher;
    private Course course;
    private LinkedList<String>groups=new LinkedList<String>();
    //El constructor de Assignment.
    public Assignment(LinkedList<String>groups){
        for(String array: groups){
            this.groups.add(array);
        }
    }
    //Añadir teacher a la clase
    public void addTeacher(Teacher teacher){
        this.teacher=teacher;
    }
    //Añadir course a la clase.
    public void addCourse(Course course){
        this.course=course;
    }
    //Añadir teacher a la clase.
    public Teacher getTeacher(){
        return this.teacher;
    }
}