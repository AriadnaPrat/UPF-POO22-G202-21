public class Lecture {
    private String group;
    private int timeSlot;
    private int type;
    private Classroom classroom;
    private Course course;
    //El constructor de Lecture
    public Lecture(String group, int timeSlot, int type){
        this.group=group;
        this.timeSlot=timeSlot;
        this.type=type;
    }
    //Añade un classroom a la lista classrooms
    public void addClassroom(Classroom classroom){
        this.classroom=classroom;
    }
    //Añade course a la variable course de Lecture
    public void addCourse(Course course){
        this.course=course;
    }
}
