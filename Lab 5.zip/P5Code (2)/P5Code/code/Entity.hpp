#ifndef _ENTITY_
#define _ENTITY_
#include "Vec2D.hpp"
#include <string> 
#include <iostream> 
#include "Nameable.hpp"
using namespace std;
class Entity : public Nameable{
    protected:
        Vec2D * pos;
        string name;
        int energy;
    public:
        Entity(Vec2D * pos1, std::string name1, int energy1): pos(pos1), name(name1), energy(energy1){};
        std::string getName(){
            return name;
        }
        void setName(std::string n){
            name=n;
        }
        int getEnergy(){
            return energy;
        }
        int compareTo(Entity * element){
            if (element->getEnergy()<energy){
                return energy;
            }else{
                return element->getEnergy();
            }
        }
        virtual void update()=0;
};
#endif