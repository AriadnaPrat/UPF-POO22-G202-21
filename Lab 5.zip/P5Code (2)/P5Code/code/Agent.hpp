#ifndef _AGENT_
#define _AGENT_
#include "Entity.hpp"
class Agent: public Entity{
    private:
        double radius;
        Vec2D * dir;
        Vec2D * target;
        double speed;
    public:
        Agent(Vec2D * pos1, std::string name1, int energy1,double radius1):Entity(pos1,name1,energy1),radius(radius1){};
        Agent(Agent * agent): Entity(agent->getPos(),agent->getName(),agent->getEnergy()),radius(agent->getRadius()){};
        void setTarget(Vec2D * target1){
            target=target1;
            Vec2D * dir1=new Vec2D(target1);
            dir1->subtract(pos);
            dir1->normalize();
            dir=dir1;
        }
        double getRadius(){
            return radius;
        }
        Vec2D * getPos(){
            return pos;
        }
        void setSpeed(double speed1){
            speed=speed1;
        }
        void update(){
            double x=dir->getX()*speed;
            double y=dir->getY()*speed;
            Vec2D * v=new Vec2D(x,y);
            pos->add(v);
        }

        bool targetReached(){
            Vec2D * v=new Vec2D(target);
            v->subtract(pos);
            if (v->length()<radius){
                return true;
            }else{
                return false;
            }
        }

        bool isColliding(Agent * agent){
            Vec2D * v=new Vec2D(pos);
            v->subtract(agent->getPos());
            double radius=radius+agent->getRadius();
            if (v->length()<radius){
                return true;
            }else{
                return false;
            }
        }
};
#endif