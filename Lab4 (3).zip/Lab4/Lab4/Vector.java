public class Vector {
    private double[] values;
    private int dim;

    public Vector(int d) {
        this.dim = d;
        this.values = new double[this.dim]; // !!!
    }
    public void set(int i, double v) { // i: index
        this.values[i] = v;
    }
    public double get(int i) {
        return this.values[i];
    }
    public void zero() {
        for (int i=0; i<this.dim; i++) {
            this.values[i] = 0;
        }
    }
    public void multiply(double s) {
        for (int i=0; i<this.dim; i++) {
            this.values[i] *= s;
        }
    }
    public void print() {
        System.out.println("Vector:");
        System.out.print("[");
        for (int i=0; i<this.dim; i++) {
            if (i<this.dim-1) {
                System.out.print(this.values[i]+", ");
            } else {
                System.out.print(this.values[i]+"]\n");
            }
        }
    }
    public void set3D(double i, double j, double k) {
        this.values[0] = i;
        this.values[1] = j;
        this.values[2] = k;
    }
    public void multiplyMat(Matrix m) {
        int[] size = m.getDimMat();
        int rows_m = size[0];
        int cols_m = size[1];
        int dim_v = this.values.length;
        double[] aux_v = new double[dim_v];

        if (rows_m != dim_v) {
            System.out.println("ERROR Incompatible dimensions");
        } else {
            for (int i=0; i<rows_m; i++) {
                double sum = 0;
                for (int j=0; j<cols_m; j++) {
                    sum += m.getMat(i, j) * this.values[j];
                }
                aux_v[i] = sum;
            }
            for (int i=0; i<rows_m; i++) {
                this.values[i] = aux_v[i];
            }
        }
    }
}