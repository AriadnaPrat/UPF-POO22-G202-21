public class AudioBuffer extends Vector {
    private Vector vector;

    public AudioBuffer(int d) {
        super(d);
        this.vector = new Vector(d);
    }
    public void changeVolume(double delta) {  
        this.vector.multiply(delta);
    }
}
