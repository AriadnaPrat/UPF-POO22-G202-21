public abstract class ColorFrame extends Frame {
    private Matrix matrix;
    
    public ColorFrame(int n, int m) {
        super(n, m);
    }
    public void setCF(int i, int j, int r, int g, int b) {
        // code here
        double val = RGBToVal(r, g, b);
        this.matrix.setMat(i, j, val);
    }
    public int[] getCF(int i, int j) {
        // code here
        double rgb=this.matrix.getMat(i,j);
        int[] res_rgb=valToRGB(rgb);
        return res_rgb;
    }
    public void changeBrightness(double delta) {
        // code here
        this.matrix.multiplyScalar(delta);
    }
    public void changeRGB(int dR, int dG, int dB) {
        // code here
        double RGB=RGBToVal(dR, dG, dB);
        valToRGB(RGB);
    }
    private int[] valToRGB(double rgb) {
        int[] ret = new int[3];
        ret[0] = ((int) rgb >> 16) & 255;
        ret[1] = ((int) rgb >> 8) & 255;
        ret[2] = ((int) rgb) & 255;
        return ret;
    }
    private double RGBToVal(int r, int g, int b) {
        double ret = (r << 16) | (g << 8) | b;
        return ret;
    }
    ///////////////////////////
}