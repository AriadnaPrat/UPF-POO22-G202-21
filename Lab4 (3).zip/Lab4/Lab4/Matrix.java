public class Matrix {
    private Vector[] values;
    private int rows, cols;
    public Matrix(int m, int n) {
        this.rows = m;
        this.cols = n;
        this.values = new Vector[this.cols]; // !!!
        for (int i=0; i<this.rows; i++) {
            this.values[i] = new Vector(this.cols);
        }
    }
    public void setMat(int i, int j, double val) {
        this.values[i].set(j, val);
    }
    public double getMat(int i, int j) {
        return this.values[i].get(j);
    }
    public int[] getDimMat() {
        int[] size = new int[2];
        size[0] = this.rows;
        size[1] = this.cols;
        return size;
    }
    public void zeroMat() {
        for (int i=0; i<this.rows; i++) {
            for (int j=0; j<this.cols; j++) {
                this.values[i].set(j, 0);
            }
        }
    }
    public void multiplyScalar(double s) {
        for (int i=0; i<this.rows; i++) {
            for (int j=0; j<this.cols; j++) {
                double value = this.values[i].get(j) * s;
                this.values[i].set(j, value);
            }
        }
    }
    public void printMat() {
        System.out.println("Matrix:");
        for (int i=0; i<this.rows; i++) {
            System.out.print("[");
            for (int j=0; j<this.cols; j++) {
                if (j<this.cols-1) {
                    System.out.print(this.values[i].get(j)+", ");
                } else {
                    System.out.print(this.values[i].get(j)+"]");
                }
            }
            System.out.println();
        }
    }
    public void create3DRotationMat(double alpha) {
        double cosAlpha = Math.cos(alpha);
        double sinAlpha = Math.sin(alpha);

        this.values[0].set3D(cosAlpha, -sinAlpha, 0);
        this.values[1].set3D(sinAlpha, cosAlpha, 0);
        this.values[2].set3D(0, 0, 1);
    }
}

// m[0].set3D(cosAlpha, -sinAlpha, 0); // ???
// Como una matríz puede usar métodos de un vector? pensaba que sería algo así como
// mat[i].set(...) entrando a cada una de las posiciones. 

        /*
        rotateMat.setMat(0, 0, 0);
        rotateMat.setMat(0, 1, -1);
        rotateMat.setMat(0, 2, 0);

        rotateMat.setMat(1, 0, 1);
        rotateMat.setMat(1, 1, 0);
        rotateMat.setMat(1, 2, 0);

        rotateMat.setMat(2, 0, 0);
        rotateMat.setMat(2, 1, 0);
        rotateMat.setMat(2, 2, 1);
        
        multiplyMat(rotateMat);
        */