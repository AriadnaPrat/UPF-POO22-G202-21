public abstract class BWFrame extends Frame {
    private Matrix matrix;
    public BWFrame(int n, int m) {
        super(n, m);
    }
    public void setBWF(int i, int j, int val) {
        this.matrix.setMat(i, j, val);
    }
    public int getBWF(int i, int j) {
        // code here
        int getBWF= ((int) this.matrix.getMat(i,j)) & 255;
        return getBWF; 
    }
    
    @Override // we indicate when override an abstract method inherited from other
    public void changeBrightness(double delta) {
        this.matrix.multiplyScalar(delta);
    }
}