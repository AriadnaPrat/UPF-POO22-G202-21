import java.awt.*;
public class Agent{
    private Vec2D pos;
    private double radius;
    private Vec2D dir;
    private Vec2D target;
    private double speed;
    
    public Agent(Vec2D v, double r){
        this.pos=v;
        this.radius=r;
    }

    public void setTarget(Vec2D target) {
        this.target=target;
        Vec2D dir=new Vec2D(target);
        dir.subtract(this.pos);
        dir.normalize();
        this.dir=dir;
    }

    public void setSpeed(double speed){
        this.speed=speed;
    }

    public Vec2D updatePosition(){
        double x=this.dir.getX()*this.speed;
        double y=this.dir.getY()*this.speed;
        Vec2D v=new Vec2D(x,y);
        this.pos.add(v);
        return this.pos;
    }

    public boolean targetReached(){
        Vec2D v;
        v=new Vec2D(this.target);
        v.subtract(this.pos);
        if (v.length()<this.radius){
            return true;
        }else{
            return false;
        }
    }

    public boolean isColliding(Agent agent){
        Vec2D v=new Vec2D(this.pos);
        v.subtract(agent.pos);
        double radius=this.radius+agent.radius;
        if (v.length()<radius){
            return true;
        }else{
            return false;
        }
    }

    public void agentPaint(Graphics g){
            int x=(int)(this.pos.getX()-this.radius);
            int y=(int)(this.pos.getY()-this.radius);
		    int d=(int)(2*this.radius);
		    g.setColor(Color.RED) ;
		    g.fillOval(x,y,d,d);
    }
}