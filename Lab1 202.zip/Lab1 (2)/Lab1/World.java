import java.awt.*;
public class World{
    private int weidth;
    private int height;
    private int marge;
    private int numAgents=10;
    private Agent agents[]= new Agent[numAgents];

    private Vec2D randomPos(){
        double x=this.marge+Math.random()*(this.weidth-2*this.marge);
        double y=this.marge+Math.random()*(this.height-2*this.marge);
        return new Vec2D(x,y);
    }

    private double randomRadius(){
        return 5+Math.random()*(this.marge-5);
    }

    public World(int weidth, int height, int marge){
        this.weidth=weidth;
        this.height=height;
        this.marge=marge;
        for(int i=0;i<this.numAgents;i++){
            this.agents[i]=new Agent(randomPos(), randomRadius());
            this.agents[i].setTarget(randomPos());
        }
    }
    
    public void manageCollisions(){
        for(int i=0; i<this.numAgents;i++){
            for (int j=i+1;j<this.numAgents;j++){
                boolean boleano=this.agents[i].isColliding(this.agents[j]);
                if (boleano==true){
                    this.agents[j].setTarget(randomPos());
                    boleano=false;
                }
            }
        }
    }

    public void simulationStep(){
        for(int i=0;i<this.numAgents;i++){
            this.agents[i].setSpeed(1);
        }
        boolean boleano=false;
        for(int i=0;i<this.numAgents;i++){
            this.agents[i].updatePosition();
            boleano=this.agents[i].targetReached();
            if(boleano==true){
                this.agents[i].setTarget(randomPos());
                boleano=false;
            }
        }
    }

    public void paint(Graphics g){
        for(int i=0;i<this.numAgents; i++){
            this.agents[i].agentPaint(g);
        }
    }
}