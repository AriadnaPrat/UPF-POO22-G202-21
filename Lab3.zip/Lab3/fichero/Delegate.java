import java.util.LinkedList;

import com.google.zxing.common.BitMatrix;
public class Delegate extends Member {
    private LinkedList<Regular> dependents = new LinkedList<Regular>(); 
    private Headquarter headOf;

    public Delegate(String name, int phone, String email, Headquarter headquarter) { // método constructor que nos ayuda instanciar el objeto Delegate en TestDelegate.java
        super(name, phone, email, headquarter); 
    }
    public void setHeadOf(Headquarter headOf) { // setter de headOf
        this.headOf = headOf;
    }
    public void addDependents(Regular regular) { // agrega miembros regulares
        this.dependents.add(regular);
    }
    public void setAvailability(Availability available){
        this.available=available;
    }
    public Image genDelegateQR(QRLib qr) { // genera los QR del delegado dado un texto, una dirección para guardarlo y unas medidas (width y height), usando los métodos de las clases Image.java y QRLib.java
        String text = "This is a QR for a Delegate Member. You don’t have to care about rising sea levels, if you live on a mega yatch.";
        String path = "src/" + this.name + "_qr.jpg";
        Image image = new Image(path, 200, 200); // crea una imagen con un nombre de fichero dado
        BitMatrix genQR = qr.generateQRCodeImage(text, 200, 200); // genera el código QR con un texto dado
        image.setBitMatrix(genQR); // pone el bitMatrix de la imagen igual que el código QR

        return image;
    }
    public Image genRegularQR(QRLib qr) {
        String text = "This is a QR for a Delegate Member. Climate change doesn’t matter, if you stay indoors.";
        String path = "src/" + this.name + "_qr.jpg";
        int width = 200;
        int height = 200;

        Image image = new Image(path, width, height); // crea una imagen con un nombre de fichero dado
        BitMatrix genQR = qr.generateQRCodeImage(text, width, height); // genera el código QR con un texto dado
        image.setBitMatrix(genQR); // pone el bitMatrix de la imagen igual que el código QR

        return image;
    }
    public boolean signUpDelegate(Delegate delegate, QRLib qr, Image image) { // verifica primero si coincide el texto (decodifíca la imagen) con el texto adecuado de delegate, retornando así un booleano
        String text_delegate = "This is a QR for a Delegate Member. You don’t have to care about rising sea levels, if you live on a mega yatch.";
        
        String text = qr.decodeQRCodeImage(image.getBitmap());
        String delegate1 = delegate.toString() + " " + text_delegate; // cada head delegate incluye su nombre en el QR text

        if (text == delegate1) {
            return true;
        } else {
            return false;
        }
    }
    public boolean signUpRegular(Regular regular, QRLib qr, Image image) {
        String text_regular = "This is a QR for a Delegate Member. Climate change doesn’t matter, if you stay indoors.";

        String text = qr.decodeQRCodeImage(image.getBitmap());
        String regular1 = regular.toString() + " " + text_regular;

        if (text == regular1) {
            return true;
        } else {
            return false;
        }
    }
    public String toString(){ // devolvemos el nombre del miembro delegado parseado en tipo de dato String
        return this.name;
    }
}