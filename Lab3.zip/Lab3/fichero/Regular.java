import java.util.LinkedList;

public class Regular extends Member {
    private Delegate responsible;
    private LinkedList<Vehicle> vehicles = new LinkedList<Vehicle>();

    public Regular(String name, int phone, String email, Headquarter headquarter, Delegate responsible) { // parámetros heredados de la clase Member, excepto responsible, el cual lo inicializamos también
        super(name, phone, email, headquarter);
        this.responsible = responsible;
    }
    public void adddVehicle(Vehicle c) { // los miembros regulares son capaces de usar vehículos a diferencia de los miembros delegados
        this.vehicles.add(c);
    }
    public void setAvailability(Availability available){ // ubicamos la disponibilidad en dias y horas que se instancio gracias al constructor de la clase Availability
        this.available=available;
    }
    public Delegate getResponsible(){ // clase getter que devuelve el responsable delegado
        return this.responsible;
    }
    public String toString(){ // devuelve el nombre del miembro regular parseado a String
        return this.name;
    }
}