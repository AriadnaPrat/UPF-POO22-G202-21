import java.util.LinkedList;
public class TestDelegate {
    static private LinkedList<Region> regions= new LinkedList<Region>();
    static private Organization organization= new Organization("Organization");
    static private LinkedList<Delegate> heads= new LinkedList<Delegate>();
    static private LinkedList<Headquarter> headquarters = new LinkedList<Headquarter>();
    public static void main(String[] args) {
        LinkedList<String[]> regions = Utility.readXML("region");
        LinkedList<String[]> headquarters = Utility.readXML("headquarter");
        LinkedList<String[]> heads = Utility.readXML("head");
        LinkedList<Headquarter> headquarterList = new LinkedList<Headquarter>();
        LinkedList<Region> regionList = new LinkedList<Region>();
        LinkedList<Delegate> headList= new LinkedList<Delegate>();
        // regions.xml
        // [0] is String name
        // [1] is String city_name
        // [2] is Integer city_population
        LinkedList<City> cityList = new LinkedList<City>(); // instanciamos un tipo City para almacenar en una lista las ciudades obtenidas del XML
        for(String[] array: regions){ // recorremos la LinkedList regions, creada como atributo anteriormente, desgranando el contenido y lo almacenamos en un array.
            LinkedList<City> cityList1 = new LinkedList<City>();
            Region region = new Region(array[0]);
            regionList.add(region);
            int mean = (array.length-1)/2;
            for (int i=1; i<mean+1; i++) { 
                City city = new City(array[i], Integer.parseInt(array[i+mean]));
                cityList.add(city);
                cityList1.add(city);
            }
            region.setCities(cityList1);
            regionList.add(region);
        }

        // visualizamos region y city
        System.out.println("REGION:");
        for (Region array: regionList) {
            System.out.print(". " + array.toString());
        }
        System.out.println();
        System.out.println("CITY:");
        for (City array: cityList) {
            System.out.print(". " + array.toString());
        }

        // headquarters.xml
        // [0] is String name
        // [1] is String email
        // [2] is String city
        LinkedList<String> cityHqList = new LinkedList<String>();
        for (String[] array: headquarters) {
            Headquarter headquarter= new Headquarter(array[0],array[1], organization);
            headquarterList.add(headquarter);
            for (int i=2; i<array.length; i++) { // city constructor means (name, population)
                cityHqList.add(array[i]);
            }
        }

        // visualizamos headquarter y city de headquarter
        System.out.println();
        System.out.println("HEADQUARTER:");
        for (Headquarter array: headquarterList) {
            System.out.print(". " + array.toString());
        }
        System.out.println();
        System.out.println("CITY HEADQUARTER:");
        for (String array: cityHqList) {
            System.out.print(". " + array.toString());
        }

        // heads.xml
        // [0] is String name
        // [1] is Integer phone
        // [2] is String email
        // [3] is String headOf
        // [4] is String days
        // [5] is Integer hours
        LinkedList<Headquarter> headquarterList1 = new LinkedList<Headquarter>(); // instanciamos un tipo una LinkedList Headquarter para almacenar los datos de heads.xml
        for(String[] array: heads){
            Headquarter headquarter = Utility.getObject(array[3], headquarterList);
            Delegate head = new Delegate(array[0], Integer.parseInt(array[1]), array[2], headquarter);
            LinkedList<String> dayss= new LinkedList<String>();
            LinkedList<Integer> hourss= new LinkedList<Integer>();
            String[] hours1=array[5].split("."); // dado que los datos de days y hours contienen "." los separamos para quedarnos con los datos
            String[] days1=array[4].split(".");
            for(String array1: days1){
                dayss.add(array1);
            }
            for(String array1: hours1){
                hourss.add(Integer.parseInt(array1));
            }
            head.setAvailability(new Availability(dayss,hourss));
            headList.add(head);
            headquarter.setHead(head);
            headquarterList1.add(headquarter);
        }

        // visualizamos el nombre de la organización, el resto de los datos extraidos de los xml lo imprimimos en una lista para mostrar que se han guardado correctamente
        System.out.println(organization.toString());
        for (Headquarter array: headquarterList) { // recorremos ahora la lista de headquarters
            System.out.println("headquarter: " + array.toString());
                for(City array2: cityList){ // recorremos la lista de ciudades almacenadas
                    for(City array3: array.getCities()){ // recorremos la lista ciudades de los headquarters
                        if(array2==array3){ // comparamos si los nombre coinciden
                            System.out.println("       city: " + array3.toString());
                        }
                    } 
            }
            System.out.println("       name_heads: " + array.getHead()); // lo mismo con los heads de cada headquarter
        }
    }
}