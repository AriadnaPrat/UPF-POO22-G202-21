import java.util.LinkedList;

public class Availability {
    private LinkedList<String> days = new LinkedList<String>();
    private LinkedList<Integer> hours = new LinkedList<Integer>();

    public Availability(LinkedList<String> days, LinkedList<Integer> hours) {
        for (String array: days) {
            this.days.add(array);
        }
        for (int array: hours) {
            this.hours.add(array);
        }
    }
}