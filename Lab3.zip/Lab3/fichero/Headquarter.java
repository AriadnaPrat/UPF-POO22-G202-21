import java.util.LinkedList;

public class Headquarter {
    private String name;
    private String email;
    private LinkedList<Member> members = new LinkedList<Member>();
    private Delegate head;
    private Organization organization;
    private LinkedList<City> cities = new LinkedList<City>();

    public Headquarter(String name, String email, Organization organization) { // método constructor que espera una estructura: nombre, correo y organización
        this.name = name;
        this.email = email;
        this.organization = organization;
    }
    public void addMember(Member members) { // método que dado un tipo miembro, lo agrega a la sede
        this.members.add(members);
    }
    public Organization getOrganization() { // obtenemos la organización a la que pertenece, este caso “organization”
        return this.organization;
    }
    public void setHead(Delegate head) { // método setter que coloca al jefe de la sede dado un nombre de la lista del archivo heads.xml
        this.head = head;
    }
    public Delegate getHead(){ // método getter que obtiene el nombre del jefe
        return this.head;
    }
    public void setCities(LinkedList<City> cities){ // método setter que nos ayudará a guardar la lista de ciudades proveniente del archivo regions.xml
        for(City array: cities){
            this.cities.add(array);
        }
    }
    public LinkedList<City> getCities(){ // método getter que devuelve una lista de ciudades almacenadas, usado en la visualización de la estructura de la organización
        return this.cities;
    }
    public String toString() { // devolvemos el nombre de la sede parseado en tipo de dato String
        return this.name;
    }
}