import java.util.LinkedList;

public class Organization {
    private String name;
    private LinkedList<Headquarter> places = new LinkedList<Headquarter>();

    public Organization(String name) { // método constructor para instanciar dado un nombre, en este caso lo llamamos “Organization”, declarado al inicio de TestDelegate.java
        this.name = name;
    }
    public LinkedList<Delegate> getDelegates(){ // método getter que devuelve los delegados de un headquarter
        LinkedList<Delegate> delegates= new LinkedList<Delegate>();
        for (Headquarter array: this.places){
            delegates.add(array.getHead());
        }
        return delegates;
    }
    public void setHdqs(LinkedList<Headquarter> places){ // método setter que indica la ciudad de un headquarter
        for (Headquarter array: places){
            this.places.add(array);
        }
    }
    public String toString(){ // devuelve el nombre de la organización parseado en tipo de dato String
        return this.name;
    }

}