import java.util.LinkedList;

public class City {
    private String name;
    private Integer population;
    private LinkedList<Headquarter> hqs = new LinkedList<Headquarter>();
    
    public City(String name, Integer population) { // obtenemos del XML el nombre de la ciudad y el número de población
        this.name = name;
        this.population = population;
    }
    public void addHQ(Headquarter hq) { // agregamos las diferentes sedes que puede haber en una ciudad
        this.hqs.add(hq);
    }
    public String toString(){ // devolvemos el nombre de la ciudad parseado en tipo de dato String
        return this.name;
    }
}