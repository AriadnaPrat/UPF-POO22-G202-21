import java.util.LinkedList;

public class Region {
    private String name;
    private LinkedList<City> cities = new LinkedList<City>();

    public Region(String name) { // método constructor que almacenará el nombre de la región del archivo regions.xml
        this.name = name;
    }
    public void setCities(LinkedList<City> cities) { // ubicamos las ciudades en regiones dado una lista de ciudades obtenidas del archivo regions.xml
        for (City array: cities) {
            this.cities.add(array);
        }
    }
    public LinkedList<City> getCities(){ // clase getter que devuelve una lista de ciudades ubicas en una región
        return this.cities;
    } 
    public String toString() { // devuelve el nombre de la región parseado a String
        return this.name;
    }
}