public class Member {
    protected String name;
    protected int phone;
    protected String email;
    protected Availability available;
    protected Headquarter headquarter;

    public Member(String name, int phone, String email, Headquarter headquarter) { // método constructor, si bien no se instancia directamente, este crea la estructura para Delegate y Regular
        this.name = name;
        this.phone = phone;
        this.email = email;
    }
    public void setAvailability(Availability a) { // método setter que coloca la disponibilidad (días, horas) obtenida del archivo heads.xl
        this.available = a;
    }
    public Headquarter getHeadquarter() { // método getter que devuelve la sede 
        return this.headquarter;
    }
}