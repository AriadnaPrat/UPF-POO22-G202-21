public class Vehicle {

    private String type;
    private int capacity;
    
    public Vehicle(String type, int capacity) { // método constructor de vehículo donde se instancia el tipo de vehículo y pasajeros del mismo
        this.type = type;
        this.capacity = capacity;
    }
}