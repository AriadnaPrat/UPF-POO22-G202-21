import java.util.LinkedList;

public class Classroom {
    // Atributos
    private String code;
    private LinkedList<Lecture>lectures=new LinkedList<Lecture>();

    // Métodos
    public Classroom(String code){ // Método constructor que inicializa el código del aula
        this.code=code;
    }

    public void addLecture(Lecture lecture){ // Agrega a la LinkedList de lecture los datos leídos del archivo lectures.xml
        this.lectures.add(lecture);
    }
    
    public String toString(){ // Método para pasar a cadena de texto dado un objeto
        return this.code;
    }
}