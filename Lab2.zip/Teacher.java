import java.util.LinkedList;

public class Teacher{
    // Atributos
    private String name;
    private LinkedList<Assignment>assignments=new LinkedList<Assignment>();

    // Métodos
    public Teacher(String name){ // Método constructor que inicializa el nombre del profesor
        this.name=name;
    }
    public void addAssignment(Assignment assignment){ // Agrega a la LinkedList de assignment los datos leídos del archivo assignments.xml
        this.assignments.add(assignment);
    }
    public String toString(){ // Método para pasar a cadena de texto dado un objeto
        return this.name;
    }
    
}