import java.util.LinkedList;

public class Student{
    // Atributos
    private String name;
    private int nia;
    private LinkedList<Enrollment> enrollments=new LinkedList<Enrollment>();

    // Métodos
    public Student(String name, int num){ // Es el método constructor de la clase Student, esta inicializa
        this.name=name;
        this.nia=num;
    }

    public void addEnrollment(Enrollment enrollment){ // Agrega a la LinkedList de enrollment los datos leídos del archivo enrollments.xml
        this.enrollments.add(enrollment);
    }

    public LinkedList<String> getCourses(LinkedList<Course> courses){ // Método de consulta que devuelve la lista de todos los cursos matriculado
        LinkedList<String> courses1= new LinkedList<String>();
        for (Enrollment array: this.enrollments){
            for(Course array1: courses){
                if(array.getCourse()==array1){
                    courses1.add(array.getCourse().toString());
                }
            }
        }
        return courses1;
    }
    
    public String toString(){ // Método para pasar a cadena de texto dado un objeto
        return this.name;
    }
}