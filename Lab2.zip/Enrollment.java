public class Enrollment {
    // Atributos
    private String seminarGroup;
    private Student student;
    private Course course;

    // Métodos
    public Enrollment(String seminarGroup){ // Método onstructor de la clase Enrollment que inicializa los seminarGroup
        this.seminarGroup=seminarGroup;
    }

    public void addCourse(Course course){ // Agrega a course los datos leídos del archivo courses.xml
        this.course=course;
    }

    public void addStudent(Student student){ // Agrega a student los datos leídos del archivo students.xml
        this.student=student;
    }

    public Course getCourse(){ // Devuelve el nombre del curso, método utilizado para obtener los cursos de un alumno
        return course;
    }
}
