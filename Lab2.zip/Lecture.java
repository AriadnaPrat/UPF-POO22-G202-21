public class Lecture {
    // Atributos
    private String group;
    private int timeSlot;
    private int type;
    private Classroom classroom;
    private Course course;

    // Métodos
    public Lecture(String group, int timeSlot, int type){ // Método constructor de Lecture, inicializa grupo, slot y type
        this.group=group;
        this.timeSlot=timeSlot;
        this.type=type;
    }

    public void addClassroom(Classroom classroom){ // Agrega a classroom los datos leídos del archivo classrooms.xml
        this.classroom=classroom;
    }

    public void addCourse(Course course){ // Agrega a course los datos leídos del archivo courses.xml
        this.course=course;
    }
}
