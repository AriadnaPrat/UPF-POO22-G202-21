import java.util.LinkedList;

public class Course{
    // Atributos
    private String name;
    private LinkedList<Enrollment>enrollments=new LinkedList<Enrollment>();
    private LinkedList<Assignment>assignments=new LinkedList<Assignment>();
    private LinkedList<Lecture>lectures=new LinkedList<Lecture>();

    // Métodos
    public Course(String name){ // Método constructor de la clase Course que inicializa
        this.name=name;
    }

    public void addLecture(Lecture lecture){ // Constructor que inicializa lecture
        this.lectures.add(lecture);
    }

    public void addAssignment(Assignment assignment){ // Agrega a la LinkedList de assignment los datos leídos del archivo assignments.xml
        this.assignments.add(assignment);
    }
    
    public void addEnrollment(Enrollment enrollment){ // Agrega a la LinkedList de enrollment los datos leídos del archivo enrollments.xml
        this.enrollments.add(enrollment);
    }

    public  String toString(){ // Método para pasar a cadena de texto dado un objeto
        return this.name;
    }
    public LinkedList<String> getTeachers(LinkedList<Teacher> teachers){ // Método de consulta que devuelve la lista de profesores de una asignatura
        LinkedList<String> teachers1= new LinkedList<String>();
        for (Assignment array: this.assignments){
            for(Teacher array1: teachers){
                if(array.getTeacher()==array1){
                    teachers1.add(array.getTeacher().toString());
                }
            }
        }
        return teachers1;
    }
}