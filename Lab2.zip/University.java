import java.util.LinkedList;

public class University {
    // Atributos
    private LinkedList<Course>courses= new LinkedList<Course>();
    private LinkedList<Classroom>classrooms= new LinkedList<Classroom>();
    private LinkedList<Student>students= new LinkedList<Student>();
    private LinkedList<Teacher>teachers= new LinkedList<Teacher>();

    // Métodos
    // Método constructor donde hacemos la lectura de los diferentes archivos .xml
    // recorriendo y alamacenandolos en un array para después agregarlos a sus respectivas listas
    public University(){
        LinkedList<Student> studentList = new LinkedList<Student>(); // Instanciamos una lista de tipo Student
        LinkedList<Teacher> teacherList = new LinkedList<Teacher>();
        LinkedList<Classroom> classroomList = new LinkedList<Classroom>();
        LinkedList<Course> courseList = new LinkedList<Course>();
        LinkedList<String[]> classrooms= Utility.readXML("classroom"); // Almacenamos los datos leídos
        LinkedList<String[]> lectures = Utility.readXML("lecture");
        LinkedList<String[]> students = Utility.readXML("student");
        LinkedList<String[]> teachers = Utility.readXML("teacher");
        LinkedList<String[]> courses = Utility.readXML("course");
        LinkedList<String[]> assignments = Utility.readXML("assignment");
        LinkedList<String[]> enrollments = Utility.readXML("enrollment");

        for(String[] array: students){ // Desgranamos el contenido de los ficheros
            Student student=new Student(array[0],Integer.parseInt(array[1])); // Los casteamos en tipo Student con el contenido desgranado
            studentList.add(student); // Y lo agregamos a la lista creado anteriormente
        }
        for(String[] array: teachers){
            Teacher teacher=new Teacher(array[0]);
            teacherList.add(teacher);
        }

        for(String[] array: courses){
            Course course=new Course(array[0]);
            courseList.add(course);
        }

        for(String[] array: classrooms){
            Classroom classroom=new Classroom(array[0]);
            classroomList.add(classroom);
        }
        for (String[] array: lectures) {
            Classroom classroom = Utility.getObject(array[0], classroomList); 
            Course course = Utility.getObject(array[1], courseList);
            Lecture lecture = new Lecture(array[4],Integer.parseInt(array[2]),Integer.parseInt(array[3])); 
            lecture.addClassroom(classroom); 
            lecture.addCourse(course);
            classroom.addLecture(lecture); 
            course.addLecture(lecture); 
        }

        for (String[] array: enrollments){
            Student student=Utility.getObject(array[0], studentList);
            Course course = Utility.getObject(array[1], courseList);
            Enrollment enrollment = new Enrollment(array[2]);
            enrollment.addStudent(student);
            enrollment.addCourse(course);
            course.addEnrollment(enrollment);
            student.addEnrollment(enrollment);
        }

        for (String[] array: assignments){
            Teacher teacher=Utility.getObject(array[0],teacherList);
            Course course = Utility.getObject(array[1], courseList);
            LinkedList<String>groupList=new LinkedList<String>();
            for(int i=2;i<array.length;i++){
                groupList.add(array[i]);
            }
            Assignment assignment=new Assignment(groupList);
            assignment.addTeacher(teacher);
            assignment.addCourse(course);
            teacher.addAssignment(assignment);
            course.addAssignment(assignment);
        }
        for(Course array: courseList){
            this.courses.add(array);
        }
        for(Student array: studentList){
            this.students.add(array);
        }
        for(Classroom array: classroomList){
            this.classrooms.add(array);
        }
        for(Teacher array: teacherList){
            this.teachers.add(array);
        }
    }

    // Métodos que retornan una lista de strings utilizando el método
    // toString de la clase Utility. Obteniendo así las diferentes listaa
    // que se han ido almacenando al leer los documentos .xml
    public LinkedList<String> getStudents(){
        return Utility.toString(this.students);
    }
    public LinkedList<String> getCourses(){
        return Utility.toString(this.courses);
    }
    public LinkedList<String> getClassrooms(){
        return Utility.toString(this.classrooms);
    }
    public LinkedList<String> getTeachers(){
        return Utility.toString(this.teachers);
    }
    public LinkedList<String> coursesOfStudent(String student){ // Método de consulta para obtener los cursos de un estudiante
        return Utility.getObject(student,this.students).getCourses(this.courses);
    }
    public LinkedList<String> teachersOfCourse(String course){ // Método de consulta para obtener los cursos de un profesor
        return Utility.getObject(course,this.courses).getTeachers(this.teachers);
    }

}
