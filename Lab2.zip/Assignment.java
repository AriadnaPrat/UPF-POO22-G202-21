import java.util.LinkedList;

public class Assignment{
    // Atributos
    private Teacher teacher;
    private Course course;
    private LinkedList<String>groups=new LinkedList<String>();

    // Métodos
    public Assignment(LinkedList<String>groups){ // Método constructor que recibe una LinkedList de grupos y se inicializa recorriendo dicha lista
        for(String array: groups){
            this.groups.add(array);
        }
    }

    public void addTeacher(Teacher teacher){ // Agrega a teacher los datos leídos del archivo teachers.xml
        this.teacher=teacher;
    }
    
    public void addCourse(Course course){ // Agrega a course los datos leídos del archivo courses.xml
        this.course=course;
    }

    public Teacher getTeacher(){ // Devuelve el nombre del profesor, método utilizado para obtener los profesores enlistados en un curso
        return this.teacher;
    }
}