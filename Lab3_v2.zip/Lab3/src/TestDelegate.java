import java.util.LinkedList;

public class TestDelegate {
    
    static private LinkedList<Region> regions;
    static private Organization organization;
    static private LinkedList<Delegate> heads;

    public static void main(String[] args) {
        // regions.xml
        // [0] is String name
        // [1-n] is String city_name
        // [2-n] is Integer city_population
        LinkedList<Region> regionList = new LinkedList<Region>();
        LinkedList<City> cityList = new LinkedList<City>();
        LinkedList<String[]> regions = Utility.readXML("region");
        for (String[] array: regions) {
            Region region = new Region(array[0]);
            regionList.add(region);
            int mean = (array.length-1)/2;
            for (int i=1; i<mean+1; i++) {
                City city = new City(array[i], Integer.parseInt(array[i+mean]));
                cityList.add(city);
            }
        }
        
        for (Region array: regionList) {
            System.out.println("reg: " + array.toString());
        }
        for (City array: cityList) {
            System.out.println("cit: " + array.toString());
        }
        
        // headquarters.xml
        // [0] is String name
        // [1] is String email
        // [2-n] is String city
        LinkedList<Headquarter> headquarterList = new LinkedList<Headquarter>();
        LinkedList<Organization> organizationList = new LinkedList<Organization>();
        LinkedList<String> cityHqList = new LinkedList<String>();
        LinkedList<String[]> headquarters = Utility.readXML("headquarter");
        for (String[] array: headquarters) {
            Organization organization = new Organization(array[2]);
            Headquarter headquarter = new Headquarter(array[0], array[1], organization); // (String name, String email, Organization organization)
            headquarterList.add(headquarter);
            organizationList.add(organization);
            for (int i=2; i<array.length; i++) { // city constructor means (name, population)
                cityHqList.add(array[i]);
            }
        }

        for (Headquarter array: headquarterList) {
            System.out.println("hq: " + array.toString());
        }
        for (Organization array: organizationList) {
            System.out.println("org: " + array.toString());
        }
        for (String array: cityHqList) {
            System.out.println("cithq: " + array.toString());
        }

        // heads.xml
        // [0] is String name
        // [1] is Integer phone
        // [2] is String email
        // [3] is String headOf
        // [4] is String days
        // [5] is Integer hours
        LinkedList<Delegate> delegateList = new LinkedList<Delegate>();
        
        LinkedList<String[]> delegates = Utility.readXML("head");
        for (String[] array: delegates) {
            Headquarter heads = Utility.getObject(array[3], headquarterList);
            Delegate delegate = new Delegate(array[0], Integer.parseInt(array[1]), array[2], heads);
            delegateList.add(delegate);
            LinkedList<String> availabilityList = new LinkedList<String>();
            for (int i=4; i<array.length; i++) {
                availabilityList.add(array[i]);
            }
        }

        for (Delegate array: delegateList) {
            System.out.println("name_heads: " + array.toString());
        }
        for (Headquarter array: headquarterList) {
            System.out.println("del: " + array.toString());
        }
        /*
        for (Availability array: availabilityList) {
            System.out.println("del: " + array.toString());
        }
        */
    }

    public LinkedList<String> getRegions() {
        return Utility.toString(this.regions);
    }
}
