import java.util.LinkedList;

public class City {
    private String name;
    private Integer population;
    private LinkedList<Headquarter> hqs = new LinkedList<Headquarter>();

    public City(String name, Integer population) {
        this.name = name;
        this.population = population;
    }
    public void addHQ(Headquarter hq) {
        this.hqs.add(hq);
    }
    public String toString() {
        return this.name;
    }
}