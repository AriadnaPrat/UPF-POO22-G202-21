import java.util.LinkedList;

public class Headquarter {
    private String name;
    private String email;
    private LinkedList<Member> members = new LinkedList<Member>();
    private Delegate head;
    private Organization organization;
    private LinkedList<City> cities = new LinkedList<City>();

    public Headquarter(String name, String email, Organization organization) {
        this.name = name;
        this.email = email;
        this.organization = organization;
    }
    public void addMember(Member members) {
        this.members.add(members);
    }
    public Organization getOrganization() {
        return this.organization;
    }
    public void setHead(Delegate head) {
        this.head = head;
    }
    public String toString() {
        return this.name;
    }
}