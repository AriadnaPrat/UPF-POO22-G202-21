public class Vehicle {
    private String type;
    private int capacity;

    public Vehicle(String type, int capacity) {
        this.type = type;
        this.capacity = capacity;
    }
}