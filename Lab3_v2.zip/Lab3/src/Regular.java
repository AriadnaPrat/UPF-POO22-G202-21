import java.util.LinkedList;

public class Regular extends Member {
    private Delegate responsible;
    private LinkedList<Vehicle> vehicles = new LinkedList<Vehicle>();

    public Regular(String name, int phone, String email, Headquarter headquarter, Delegate responsible) {
        super(name, phone, email, headquarter);
        this.responsible = responsible;
    }
    public void adddVehicle(Vehicle c) {
        this.vehicles.add(c);
    }
}