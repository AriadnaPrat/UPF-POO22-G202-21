import java.util.LinkedList;

public class Organization {
    private String name;
    private LinkedList<Headquarter> places = new LinkedList<Headquarter>();

    public Organization(String name) {
        this.name = name;
    }
    public String toString() {
        return this.name;
    }
}