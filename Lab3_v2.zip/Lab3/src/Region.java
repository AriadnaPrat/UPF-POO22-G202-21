import java.util.LinkedList;

public class Region {
    private String name;
    private LinkedList<City> cities = new LinkedList<City>();

    public Region(String name) {
        this.name = name;
    }
    public void setCities(LinkedList<City> cities) {
        for (City array: cities) {
            cities.add(array);
        }
    }
    public String toString() {
        return this.name;
    }
}