import java.util.LinkedList;

public class Member {
    protected String name;
    protected int phone;
    protected String email;
    protected Availability available;
    protected Headquarter headquarter;

    public Member(String name, int phone, String email, Headquarter headquarter) {
        this.name = name;
        this.phone = phone;
        this.email = email;
    }
    public void setAvailability(Availability a) {
        this.available = a;
    }
    public Headquarter getHeadquarter() {
        return this.headquarter;
    }
}